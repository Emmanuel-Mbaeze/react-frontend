import React from "react"
import Styled from "styled-components"
const Card = ({title ,para,icon,direc})=>{
    return(
<Container direc={direc}>
<Wrapper>
<Title>
{title}
</Title>
<Para>
{para}
</Para>
<Icon>
    <Logo src={icon}/>
</Icon>
</Wrapper>
</Container>
    )
}
export default Card
const Container = Styled.div`
width:250px;
height:230px;
box-shadow:1px 1px 4px 3px silver;
border-radius:7px;
border-top: ${({direc})=>direc};
margin:20px;
display:flex;
justify-content:center;
align-items:center;
`
const Wrapper = Styled.div`
width:240px;
height:220px;
color: ;
// background:red
`
const Title = Styled.div`
font-size:30px;
font-weight:500;
margin-bottom:7px
`
const Para = Styled.div`
font-size:14px;
font-weight:370;
color:#aaa;
margin-bottom:30px
`
const Icon = Styled.div`
width:100%;
height:40%;
// background:pink;
display:flex;
justify-content:end;
align-items:end;
`
const Logo = Styled.img`
width:40px;
height:40px;
object-position:cover;
`