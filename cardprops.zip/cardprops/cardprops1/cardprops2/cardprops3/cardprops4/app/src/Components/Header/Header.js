import React from "react"
import Styled from "styled-components"
import Card from "../Homescreen/Extra"
import Pic from "../../img/1.png"
import Pic1 from "../../img/2.png"
import Pic2 from "../../img/3.png"
import Pic3 from "../../img/4.png"
const Main=()=>{
	return(
		<Container>
        <Wrapper>
<One>
<Card
title="Supervisor"
para="Monitoring activity to identify project  roadblock "
icon={Pic}
direc="3px solid aqua"
/>
</One>
<Two>
<Card
title="Team builder"
para="Scan our talent network to create the optimal team for your project  "
icon={Pic1}
direc="3px solid red"/>
<Card
title="Calculator"
para="Uses data fro past project to provide better delivery estimate"
icon={Pic3}
direc="3px solid orange"
/>
</Two>
<Three>
<Card
title="Karma"
para="Regularly eveluate our talent to ensure quality"
icon={Pic2}
direc="3px solid blue"/>
</Three>
		</Wrapper>
		</Container>
	)
}
export default Main
const Container = Styled.div`
width:100%;
Height:100vh;
// background:red;
display:flex;
justify-content:center;
align-items:center;
`
const Wrapper = Styled.div`
width:70%;
height:70vh;
// background:pink;
display:flex;
justify-content:space-between;
`
const One = Styled.div`
width:32%;
height:70vh;
// background:blue;
display:flex;
justify-content:center;
align-items:center;
`
const 	Two = Styled.div`
width:32%;
height:70vh;
// background:green;
display:flex;
flex-direction:column;
justify-content:space-between;
align-items:center;
`
const Three = Styled.div`
width:32%;
height:70vh;
// background:white;
display:flex;
justify-content:center;
align-items:center;
`