 import React from "react"
import Main from "./Components/Header/Header";

 const App = ()=>{
     return(
         <div>
          <Main/>
         </div>
     )
 }
 export default App;